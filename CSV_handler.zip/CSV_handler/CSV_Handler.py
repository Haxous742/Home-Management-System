import csv 

class CSV_Handler:


    #nested Dictionary 
    #formal of Dict = {'Username' : { 'Id' : <> , 'Password' : <> , 'Address' : <> , 'Houses' : ['House_1' , 'House_2'] } }

    @staticmethod
    def loadMembers():
        dict = {}
        with open('Members.csv',mode = 'r') as file:
            reader = csv.reader(file)
            for row in reader:  #format of row in CSV file: Username,Id,Password,Address,House_1%House_2... (seperated by %) 
                dict[row[0]] = { 'Id':row[1], 'Password':row[2] ,'Address':row[3] ,'Houses': row[4].strip().split("%") }

        return dict
    
    @staticmethod
    def updateMembers(dict):
        with open('Members.csv',mode ='w', newline='') as file:
            writer = csv.writer(file)
            for key in dict.keys():
                Houses = ''
                for val in dict[key]['Houses']:
                    Houses+=val +"%"
                row = [key,dict[key]['Id'],dict[key]['Password'],dict[key]['Address'],Houses]
                writer.writerow(row)

#========================================================================================================================================
    #nested dictionary
    #format = {"device_id" : {"name" : <> , "type" : <>, "status" : <> , "attributes" :{"attribute1" : "status","attribute2":"status"}}}

    def loadDevices():
        with open("Devices.csv",mode = 'r') as file:
            dict = {}
            reader = csv.reader(file)
            for row in reader:  #Formal for CSV file : device_id,name,type,status,attribute1_status,attribute2_status ....
                dict_temp = {}
                for i in range(4,len(row)):
                    temp = row[i].strip().split("_")
                    dict_temp[temp[0]] = temp[1]

                dict[row[0]] = {"name" : row[1],"type" : row[2], "status" : row[3], "attributes" : dict_temp}

            return dict
        
    def updateDevices(dict):
        with open("Devices.csv", mode = 'w', newline='') as file:
            writer = csv.writer(file)
            for key in dict.keys():
                row = [key,dict[key]["name"],dict[key]["type"],dict[key]["status"]]
                for keys in dict[key]["attributes"]:
                    str_temp = f'{keys}_{dict[key]["attributes"][keys]}'
                    row.append(str_temp)
                writer.writerow(row)

#===================================================================================================================
    #nested dictionaries
    #format = 
    
                

        
                