import CSV_Handler as csvh

class Members:
    Member_details = {}